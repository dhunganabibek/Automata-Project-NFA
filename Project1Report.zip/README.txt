TEAM MEMBERS: Santona Subedi, Dhan Limbu, Bibek Dhungana

The project is implementation of NFA. It takes a string input and decides if the 
given input is accepted or rejected by the NFA.

The code is implemented in Python.

The main(entry point of the program is main.py)

Command to Run the program:
python main.py

Make sure latest version of python is installed and python is added to path.
To check if python is installed and added in the path. Run this command:
python --version

Also, place proj-1-machine.txt and proj-1-machine-1.txt in current working directory.

"proj-1-machine.txt" have already tuple of input string in the file. For the file "proj-1-machine-1.txt", It will ask you 
to enter the input string.

